(height, percentage, charging, low, lpm, color, base)
{
    var colorString = "rgb(" + color.join() + ")",
        scale = Math.floor(height / 20),
        fullHeartData,
        halfHeartData,
        partialHeartData,
        finalCanvas = document.createElement("canvas"),
        finalContext = finalCanvas.getContext("2d");
    base = "rgba("+base.join()+")";

    function initHeart(canvas, context, color) {
        canvas.width = scale * 8;
        canvas.height = scale * 7;
        context.fillStyle = color;
        context.fillRect(0, 0, scale * 8, scale * 7);
        context.clearRect(0, 0, scale, scale);
        context.clearRect(scale * ((height>42)?3.5:3.0), 0, scale *1, scale);
        context.clearRect(scale * 7, 0, scale, scale);
        context.clearRect(0, scale * 4, scale, scale);
        context.clearRect(scale * 7, scale * 4, scale, scale);
        context.clearRect(0, scale * 5, scale * 2, scale * 2);
        context.clearRect(scale * 6, scale * 5, scale * 2, scale * 2);
        context.clearRect(scale * 2, scale * 6, scale, scale);
        context.clearRect(scale * 5, scale * 6, scale, scale);
    }
    var fullHeartCanvas = document.createElement("canvas"),
        fullHeartContext = fullHeartCanvas.getContext("2d");
    initHeart(fullHeartCanvas, fullHeartContext);
    fullHeartData = fullHeartContext.getImageData(0, 0, scale * 8, scale * 7);

    if(percentage < 100) {
        var emptyHeartCanvas = document.createElement("canvas"),
            emptyHeartContext = emptyHeartCanvas.getContext("2d");
        initHeart(emptyHeartCanvas, emptyHeartContext, base);
        //emptyHeartContext.clearRect(scale, scale, scale * 2, scale);
        //emptyHeartContext.clearRect(scale * 4, scale, scale * 3, scale);
        //emptyHeartContext.clearRect(scale, scale * 2, scale * 6, scale * 2);
        //emptyHeartContext.clearRect(scale * 2, scale * 4, scale * 4, scale);
        //emptyHeartContext.clearRect(scale * 3, scale * 5, scale * 2, scale);
        emptyHeartData = emptyHeartContext.getImageData(0, 0, scale * 8, scale * 7);
    }
    if(percentage % 10) {
      //partial heart
      var partialHeart = document.createElement("canvas"),
      partialContext = partialHeart.getContext("2d");
      initHeart(partialHeart, partialContext, colorString);
      var w = (percentage % 10)/10.0 * (scale*8);
      partialContext.putImageData(emptyHeartData, 0, 0, w, 0, scale *8-w, scale *7);
      partialHeartData = partialContext.getImageData(0, 0, scale * 8, scale * 7);
    }
    finalCanvas.width = scale * 44;
    finalCanvas.height = scale * 16;
    for(var i = 0; i < 10; i++) {
        finalContext.putImageData((i+1)*10 < percentage ? fullHeartData : i*10 <percentage ? partialHeartData : emptyHeartData, (i % 5) * scale * 9, i < 5 ? scale * 9 : 0);
    }
    return finalCanvas.toDataURL("image/png");
}
