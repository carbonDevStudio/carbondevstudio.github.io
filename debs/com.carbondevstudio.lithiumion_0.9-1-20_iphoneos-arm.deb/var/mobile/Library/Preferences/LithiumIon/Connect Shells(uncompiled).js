(h, p, ch, l, col){

var height = h,
    percentage = p,
    charging = ch,
    low = l;

var color = "black",
    PPB = 20,
    maxBD = height * 0.285,
    minBD = 0,//maxBD * 0.2,
    deltaBD = maxBD - minBD,
    padding = maxBD * 0.32,
    edgeOffset = (maxBD /3) + (padding /2),
    halfHeight = height /2,
    lineWidth = maxBD * 0.1,
    width = maxBD * 5 + (padding *4) + (lineWidth *2);
    //maxWidth = maxBD * 5 + (padding *4),
    //width = (maxWidth -(maxBD - sizeForBall(1))/2- (maxBD - sizeForBall(5))/2)+1.5;

color = "rgb(" + col.join() + ")";

//var canvas = document.getElementById("myCanvas");
var canvas = document.createElement("canvas");
var ctx = canvas.getContext("2d");

canvas.width = width;
canvas.height = height;
         


function sizeForBall(num){
    var used = (num-1) *20,
    remain = Math.max(0,Math.min(20, percentage - used));
    return minBD + Math.floor(((remain / PPB) * deltaBD));
}


//ctx.font = "bold " + 50 + "pt Helvetica";
    //ctx.textAlign = "center";
    //ctx.textBaseline = "middle";
    //ctx.fillStyle = "rgba(155,20,190,1.0)";
    //var textAxis = 100;
//ctx.fillText(width, textAxis, 100);

//ctx.fillStyle= "black";
//ctx.fillRect(0,0,width,height);

    //draw lines
if (low) color = "#FF3B30";
if (charging) color = "#0CF";
if (percentage ==100) color = "#4CD964";
//color = "black";
//color = "rgb(" + col.join() + ")";

ctx.strokeStyle = color;
ctx.fillStyle = color;
ctx.lineWidth = lineWidth;

var startX = width - Math.ceil(maxBD /2) - 1 - (lineWidth);
//var startX = width - Math.ceil(sizeForBall(1) /2) - 1 - (lineWidth); //for without shells

var x = startX;

function moveToNextOrigin(v){
    return (v-(maxBD + padding));
}
function bX(n){
    return startX - ((maxBD + padding) * (n-1));
}
function bY(n){
    var z = 1;
    if (n % 2) z= -1;
    z = halfHeight + z*edgeOffset;
    return z;
    //return halfHeight;
}
function toRad(y){
    return (Math.PI/180)*y;
}

function drawBallAt(n, x, y){
    ctx.moveTo(x + (sizeForBall(n)/2), y);
    ctx.arc(x, y,(sizeForBall(n)/2), 0, toRad(360));
}

function drawBall(n){

    drawBallAt(n, bX(n),bY(n));
}

function drawMaxBall(n){
    ctx.moveTo(bX(n) + maxBD/2, bY(n));
    ctx.arc(bX(n), bY(n), maxBD/2, 0, toRad(360));
}
function drawClipBall(n){
    ctx.moveTo((bX(n) + maxBD/2)-1, bY(n));
    ctx.arc(bX(n), bY(n), (maxBD/2)-1, 0, toRad(360));
}


//ctx.moveTo(x, halfHeight- edgeOffset);

// x = moveToNextOrigin(x);
// ctx.lineTo(x, halfHeight + edgeOffset);
// x = moveToNextOrigin(x);
// ctx.lineTo(x, halfHeight - edgeOffset);
// x = moveToNextOrigin(x);
// ctx.lineTo(x, halfHeight + edgeOffset);
// x = moveToNextOrigin(x);
// ctx.lineTo(x, halfHeight-edgeOffset);
ctx.moveTo(bX(1),bY(1));
ctx.lineTo(bX(2),bY(2));
ctx.lineTo(bX(3),bY(3));
ctx.lineTo(bX(4),bY(4));
ctx.lineTo(bX(5),bY(5));

if (!((percentage == 100) && charging)){
ctx.stroke();
}
//ctx.stroke();


ctx.beginPath();
drawClipBall(1);
drawClipBall(2);
drawClipBall(3);
drawClipBall(4);
drawClipBall(5);

ctx.lineWidth = lineWidth *1.3;
ctx.stroke();

ctx.save();
ctx.clip();
ctx.clearRect(0,0,width,height);
ctx.restore();

ctx.beginPath();
//drawBallAt(5, bX(1), bY(1));
drawBall(1);
drawBall(2);
drawBall(3);
drawBall(4);
drawBall(5);

ctx.fill();

return canvas.toDataURL("image/png");
}
