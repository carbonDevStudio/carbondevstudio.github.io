(h, p, ch, l, col){

var height = h,
    percentage = p,
    charging = ch,
    low = l;

var color = "black",
    PPB = 20,
    maxBD = height * 0.3,
    minBD = maxBD * 0.35,
    deltaBD = maxBD - minBD,
    padding = maxBD * 0.2,
    edgeOffset = (maxBD /3) + (padding /2),
    halfHeight = height /2,
    maxWidth = maxBD * 5 + (padding *4),
    width = (maxWidth -(maxBD - sizeForBall(1))/2- (maxBD - sizeForBall(5))/2)+1.5;

color = "rgb(" + col.join() + ")";
//var canvas = document.getElementById("myCanvas");
var canvas = document.createElement("canvas");
var ctx = canvas.getContext("2d");

canvas.width = width;
canvas.height = height;
         


function sizeForBall(num){
    var used = (num-1) *20,
    remain = Math.max(0,Math.min(20, percentage - used));
    return minBD + Math.floor(((remain / PPB) * deltaBD));
}

function moveToNextOrigin(v){
    return (v-(maxBD + padding));
}
//ctx.font = "bold " + 50 + "pt Helvetica";
    //ctx.textAlign = "center";
    //ctx.textBaseline = "middle";
    //ctx.fillStyle = "rgba(155,20,190,1.0)";
    //var textAxis = 100;
//ctx.fillText(width, textAxis, 100);


    //draw lines
if (low) color = "#FF3B30";
if (charging) color = "#0CF";
if (percentage ==100) color = "#4CD964";

ctx.strokeStyle = color;
ctx.fillStyle = color;
ctx.lineWidth = maxBD *0.1;
var x = width - Math.ceil(sizeForBall(1) /2) - 1;
ctx.moveTo(x, halfHeight- edgeOffset);

x = moveToNextOrigin(x);
ctx.lineTo(x, halfHeight + edgeOffset);
x = moveToNextOrigin(x);
ctx.lineTo(x, halfHeight - edgeOffset);
x = moveToNextOrigin(x);
ctx.lineTo(x, halfHeight + edgeOffset);
x = moveToNextOrigin(x);
ctx.lineTo(x, halfHeight-edgeOffset);

if (!(percentage ==100 && charging)){
    ctx.stroke();
}



function toRad(y){
return (Math.PI/180)*y;
}

x = width - Math.ceil(sizeForBall(1) /2) - 1;
ctx.beginPath();
ctx.moveTo(x, halfHeight - edgeOffset);
ctx.arc(x, halfHeight - edgeOffset,(sizeForBall(1)/2), 0, toRad(360));
ctx.fill();

x=  moveToNextOrigin(x);
ctx.moveTo(x, halfHeight + edgeOffset);
ctx.arc(x,halfHeight + edgeOffset,(sizeForBall(2)/2), 0, toRad(360));
ctx.fill();

x=  moveToNextOrigin(x);
ctx.moveTo(x, halfHeight-edgeOffset);
ctx.arc(x, halfHeight -edgeOffset,(sizeForBall(3)/2), 0, toRad(360));
ctx.fill();

x=  moveToNextOrigin(x);
ctx.moveTo(x, halfHeight + edgeOffset);
ctx.arc(x,halfHeight + edgeOffset,(sizeForBall(4)/2), 0, toRad(360));
ctx.fill();

x=  moveToNextOrigin(x);
ctx.moveTo(x, halfHeight -edgeOffset);
ctx.arc(x, halfHeight -edgeOffset,(sizeForBall(5)/2), 0, toRad(360));
ctx.fill();


ctx.font = "bold " + 50 + "pt Helvetica";
ctx.textAlign = "center";
ctx.textBaseline = "middle";
ctx.fillStyle = "rgba(155,20,190,1.0)";
var textAxis = 100;
//ctx.fillText(sizeForBall(5), halfHeight, 150);

return canvas.toDataURL("image/png");
}