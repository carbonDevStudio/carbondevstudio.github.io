(h, p, ch, l,lpm, col,base){

var height = h,
    percentage = p,
    charging = ch,
    low = l;

var color = "black",
    PPB = 20,
    maxBD = Math.ceil(height * 0.285),
    minBD = 0,//maxBD * 0.2,
    deltaBD = maxBD - minBD,
    padding = maxBD * 0.32,
    edgeOffset = (maxBD /3) + (padding /2),
    halfHeight = height /2,
    lineWidth = maxBD * 0.1,
    width = maxBD * 5 + (padding *4) + (lineWidth *2);

base = "rgba("+ base.join() + ")";
color = "rgb("+ col.join() + ")";
    
//var canvas = document.getElementById("myCanvas");
var canvas = document.createElement("canvas");

var ctx = canvas.getContext("2d");

canvas.width = width;
canvas.height = height;
         


function sizeForBall(num){
    var used = (num-1) *20,
    remain = Math.max(0,Math.min(20, percentage - used));
    return minBD + ((remain / PPB) * deltaBD);
}
//ctx.fillStyle = "blue";
//ctx.fillRect(0,0,width,height);
/*

if (low) {color = "#FF3B30"; shadow = "rgba(255, 59, 48, 0.3)";}
if (charging){ color = "#0CF"; shadow= "rgba(0, 204, 255, 0.3)";}
if (percentage ==100) {color = "#4CD964"; shadow= "rgba(76, 217, 100, 0.3)";}
*/
//ctx.strokeStyle = color;
ctx.fillStyle = color;
ctx.lineWidth = lineWidth;

var startX = width - Math.ceil(maxBD /2) - 1 - (lineWidth);


var x = startX;

function moveToNextOrigin(v){
    return (v-(maxBD + padding));
}
function bX(n){
    return startX - ((maxBD + padding) * (n-1));
}
function bY(n){
    var z = 1;
    if (n % 2) z= -1;
    z = halfHeight + z*edgeOffset;
    return z;
    //return halfHeight;
}
function toRad(y){
    return (Math.PI/180)*y;
}

function drawBallAt(n, x, y){
    ctx.moveTo(x + (sizeForBall(n)/2), y);
    ctx.arc(x, y,(sizeForBall(n)/2), 0, toRad(360));
}

function drawBall(n){

    drawBallAt(n, bX(n),bY(n));
}

function drawMaxBall(n){
    ctx.moveTo(bX(n) + maxBD/2, bY(n));
    ctx.arc(bX(n), bY(n), maxBD/2, 0, toRad(360));
}
function drawClipBall(n){
    ctx.moveTo((bX(n) + maxBD/2)-.2, bY(n));
    ctx.arc(bX(n), bY(n), (maxBD/2)-.2, 0, toRad(360));
}


var i = 5;


ctx.moveTo(bX(i),bY(i));
for(; i>1; i--){
    if(sizeForBall(i)<maxBD){
        if(i != 1) ctx.lineTo(bX(i-1),bY(i-1));
    }else break;
}
ctx.strokeStyle = base;
ctx.stroke();


ctx.strokeStyle = color;


ctx.beginPath();
ctx.moveTo(bX(i),bY(i));
for(; i>1; i--){
    if(i != 1) ctx.lineTo(bX(i-1),bY(i-1));
}

ctx.stroke();

ctx.beginPath();
drawClipBall(1);
drawClipBall(2);
drawClipBall(3);
drawClipBall(4);
drawClipBall(5);


ctx.save();
ctx.clip();
ctx.clearRect(0,0,width,height);
ctx.restore();

ctx.beginPath();
drawMaxBall(1);
drawMaxBall(2);
drawMaxBall(3);
drawMaxBall(4);
drawMaxBall(5);

//ctx.fillStyle = "blue";
//ctx.fill();

ctx.fillStyle = base;
ctx.fill();


ctx.beginPath();

drawBall(1);
drawBall(2);
drawBall(3);
drawBall(4);
drawBall(5);

ctx.fillStyle = color;
ctx.fill();

ctx.font = "bold " + 50 + "pt Helvetica";
ctx.textAlign = "center";
ctx.textBaseline = "middle";
ctx.fillStyle = "rgba(155,20,190,1.0)";


//ctx.fillText(Number(sizeForBall(5)).toPrecision(3), width/2, halfHeight);

return canvas.toDataURL("image/png");
}