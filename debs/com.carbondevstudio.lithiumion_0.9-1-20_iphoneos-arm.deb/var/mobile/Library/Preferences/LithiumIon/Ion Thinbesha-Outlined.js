(hi, p, ch, l,lpm, col,base){

	var h=hi,
	    percentage = p,
	    charging = ch,
	    low = l,
	    height = h-10,
	    height = h,
		emptyBarCanvas = document.createElement("canvas"),
		emptyBarContext = emptyBarCanvas.getContext("2d"),
		emptyBarData,
		fullBarCanvas = document.createElement("canvas"),
		fullBarContext = fullBarCanvas.getContext("2d"),
		fullBarData,
		//finalCanvas = document.getElementById("myCanvas"),
		finalCanvas = document.createElement("canvas"),
		finalContext = finalCanvas.getContext("2d"),
		barWidth = Math.round(2 + height / 6.5),
		//barHeight = 2 + height / 2,
		barHeight = Math.round(2 + height * 0.6),
	    //barHeight = 2 + height * 0.5,
		//radius = Math.round(barWidth / 2 -1),
	    radius = barWidth / 2 -1,
		horizontalPadding = Math.ceil(height / 16),
		totalWidth = barWidth * 5 + horizontalPadding * 4,
		colorString = "black",
		barData,
		baseString= "rgba("+base.join()+")";



    finalCanvas.width = totalWidth;
    finalCanvas.height = barHeight;
    emptyBarCanvas.width = barWidth;
    emptyBarCanvas.height = barHeight;
    fullBarCanvas.width = barWidth;
    fullBarCanvas.height = barHeight;



	function drawPath(ctx) {
	    ctx.beginPath();
	    ctx.arc(barWidth / 2 , barHeight - radius - 1.7, radius, 0, Math.PI);
	    ctx.lineTo(1, radius + 1);
	    ctx.arc(barWidth / 2, radius + 1.7, radius, Math.PI, 0);
	    ctx.lineTo(barWidth - 1, barHeight - radius - 1);
	    ctx.clip();
	    ctx.lineWidth = Math.floor(height / 20);
	    //ctx.strokeStyle = colorString;
	}

	// emptyBarContext.fillStyle = "rgba(0,0,0,0.35)";
 //    fullBarContext.fillStyle = colorString;
 //    emptyBarContext.strokeStyle = "rgba(0,0,0,0.25)";
	emptyBarContext.fillStyle = baseString;//"rgba(" + base.join() + ")";
	emptyBarContext.strokeStyle =baseString;// "rgba(" +base.split(0,2).join()",0.3)";
	fullBarContext.fillStyle = "rgb(" + col.join() +")";

    /*if(low) {
	fullBarContext.fillStyle = "#FF3B30";
	emptyBarContext.fillStyle =base;// "rgba(255, 59, 48, 0.4)";
	emptyBarContext.strokeStyle ="rgba(255, 59, 48, 0.25)";
    }
    if (charging && percentage ==100){
	fullBarContext.fillStyle = "#0CF";
    }else if(charging || percentage == 100) {
	fullBarContext.fillStyle = "#4CD964";
	emptyBarContext.fillStyle = "rgba(76, 217, 100, 0.4)";
	emptyBarContext.strokeStyle ="rgba(76, 217, 100, 0.25)";
   }


*/
    drawPath(emptyBarContext);

    emptyBarContext.fill();
    emptyBarContext.stroke();

    emptyBarData = emptyBarContext.getImageData(0, 0, barWidth, barHeight);

    drawPath(fullBarContext);
    fullBarContext.fill();
    //fullBarContext.stroke();
    fullBarData = fullBarContext.getImageData(0, 0, barWidth, barHeight);

    for(var i = 0; i < 5; i++) {

		if(percentage <= 20 * i)
		    barData = emptyBarData;
		else if(percentage >= 20 * (i+1) )
		    barData = fullBarData;
		else {
		    finalContext.putImageData(fullBarData,totalWidth -barWidth - i * (barWidth + horizontalPadding), 0);
		    barData = emptyBarContext.getImageData(0, 0, barWidth, (barHeight - 6) * (1 - (percentage - (20 * i)) / 20) + 3);
		}

		finalContext.putImageData(barData,totalWidth -barWidth -i * (barWidth + horizontalPadding), 0);
    }

    return finalCanvas.toDataURL("image/png");

}
