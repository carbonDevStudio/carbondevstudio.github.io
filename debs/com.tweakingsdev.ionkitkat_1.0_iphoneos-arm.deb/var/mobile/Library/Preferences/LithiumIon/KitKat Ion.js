(e, l, h, m, lpm, d, base) {//height,percent,charge,low,lpm,fill,base
    var c = Math.round(.6 * e),
        b = Math.round(.4 * e),
        g = Math.floor(1 + 3 * b / 14),
        k = Math.floor(1 + c / 11),
        f = document.createElement("canvas"),
        a = f.getContext("2d");
    d = d.join();
    base = base.join();
    f.width = b;
    f.height = Math.round(.7 * e);
    a.fillStyle = "rgba(" + base + ")";
    a.fillRect(0, 0, b, c);
    a.fillStyle = "rgb(" + d + ")";
    //m && (a.fillStyle = "#F00");
    //h && (a.fillStyle = "#0F0");
    a.fillRect(0, (100 - l) / 100 * c, b, c);
    a.clearRect(0, 0, g, k);
    a.clearRect(b - g, 0, g, k);
    a.clearRect(0, c, b, e);
    a.globalCompositeOperation = "xor";
    a.fillStyle = "rgb(" + d + ")";
    h && (a.beginPath(), a.moveTo(Math.round(.6 * b), Math.round(.19 * c)), a.lineTo(Math.round(.55 * b), Math.round(.45 * c)), a.lineTo(Math.round(.8 * b), Math.round(.45 * c)), a.lineTo(Math.round(.4 * b), Math.round(.86 * c)), a.lineTo(Math.round(.45 * b), Math.round(.58 * c)), a.lineTo(Math.round(.2 * b), Math.round(.58 * c)), a.closePath(), a.fill());
    return f.toDataURL("image/png")
}
